Pseint

Para el archivo Saludo.psc, probamos con el nombre "Valentina" y con el número 456, obteniendo como resultado un estado exitoso en ambas pruebas.

Para el archivo EdadDias.psc, probamos ingresando las edades de 32 y 18, obteniendo como resultado un estado exitoso tanto en la primera como en la segunda prueba.

Para el archivo Propinas.psc, realizamos la primera prueba con los valores 200.000, 10 y 15, y la segunda con 50.000, 5 y 20, obteniendo un estado exitoso en las dos.

Para el archivo PromedioNotas.psc, evaluamos las notas 3.0, 4.5, 3.8 en la prueba uno y 4.2, 4.0, 4.9 en la prueba dos, obteniendo resultados exitosos en ambas.



