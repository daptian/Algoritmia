Pon el pocillo blanco en la mesa.
Llena la jarra con 200 ml de agua y enciéndela.
Espera hasta que la jarra se apague sola.
Echa 2 cucharaditas de café en el pocillo.
Vierte el agua hasta 1 cm del borde.
Revuelve con la cuchara 10 veces.
Entrega el pocillo. Fin.
