Algoritmo EdadEnDias
	Definir Edad Como Entero
	Escribir 'Ingresar edad'
	Leer Edad
	Edad <- Edad*365
	Escribir 'Ha vivido ', Edad
FinAlgoritmo
